# Morse Dekódoló 1.1.0

Készítette: **Antal Vincz M0GLU · 2026**

YouTube: https://www.youtube.com/@M0GLU

Magyar kezelőfelületű, offline Python-program Windowsra. Hangkártyáról vagy
WAV/OGG hangfájlból dekódol Morse-jeleket. Alapbeállítása 800 Hz, 200 Hz
sávszélesség, 20 WPM és −42 dBFS zajzár.

## A kész Windows-program indítása

1. Csomagolja ki a **teljes** Windows ZIP-et egy írható mappába.
2. Indítsa el a `MorseDekodolo.exe` fájlt. Python telepítése nem szükséges.
3. Az `_internal` mappát hagyja az EXE mellett; ez tartalmazza a futtatókörnyezetet.

A mellékelt változat Windows x64 rendszerre készült, Python 3.13 futtatókörnyezettel.
A csomag nincs digitálisan aláírva.

A **Névjegy és licencek** gomb megnyitja a készítő adatait, a YouTube-
csatorna hivatkozását, az MIT felhasználási feltételeit és a külső összetevők
teljes licencszövegeit. A Windows ZIP nem tartalmaz forráskódot vagy buildfájlokat.

## Élő vétel

Válasszon hangbemenetet (mikrofon, vonalbemenet vagy meglévő virtuális
hangkábel), majd kattintson az **Élő vétel indítása** gombra. A Windowsban a
program számára engedélyezett hangbemenet szükséges. Másik program hangjához
használható a hangkártya „Stereo Mix” bemenete, ha elérhető; automatikus
WASAPI loopback nincs beépítve.

Az oszcilloszkóp 50 ms időtartamot mutat: felül a bejövő, alul a szűrt jel
látható. Mindkét sáv amplitúdóskálája automatikus, ezért a jelszintet a dBFS
kijelzésen hasonlítsa össze. A 0 dBFS a digitális teljes kivezérlés; túlvezérlés
esetén csökkentse a bemeneti hangerőt. A program nem játssza ki a hangot.

### Oszcilloszkóp és spektrumanalizátor a főablakban

A főablakban egymás mellett látható a két kijelző: balra a rövidebb
oszcilloszkóp, jobbra a szélesebb spektrumanalizátor. Mindkettő együtt
méreteződik a főablakkal. A spektrum folyamatosan látható, nincs külön
megnyitandó vagy bezárandó ablaka.

- Kék görbe: a nyers bejövő hang; zöld görbe: a sávszűrő kimenete.
- Aranyszínű szaggatott vonal: az alkalmazott középfrekvencia.
- Zöld árnyékolás: az áteresztett sáv, középfrekvencia ± sávszélesség/2.
- Automatikus span: a sávszélesség négyszerese, a középfrekvencia körül.
  Például 800 Hz / 200 Hz beállításnál 400–1200 Hz látszik (800 Hz span).
  A kijelzés 0 Hz-nél és a mintavétel felénél korlátozott, és középen tartja
  a hangolási frekvenciát. A span a menet közbeni szűrőállítást is követi.
- A csúcs kijelzése megadja a frekvenciát, az eltérést (Δ), és hogy a csúcs
  az áteresztett sávon belül van-e. Jelentős csúcs nélkül ezt külön jelzi.

A spektrum legfeljebb az utolsó fél másodperc hangjából készül, Hann-ablakkal,
és hozzávetőleg 20 alkalommal frissül másodpercenként. Függőleges skálája
−100…0 dBFS; teljes félmásodperces adatnál a frekvenciafelbontás körülbelül
2 Hz. A csúcs frekvenciája interpolált becslés. A kijelző hangfájlnál és a
belső tesztjelnél is működik; gyors fájlfeldolgozáskor a képernyő frissítésénél
gyorsabban haladhat a dekódolás.

## WAV és OGG

**WAV / OGG megnyitása**, majd **Fájl dekódolása**. Normál esetben az
eredeti időzítéssel fut, a **Gyors fájlfeldolgozás** bejelölésével pedig a
lehető leggyorsabban. A dekódolás mindkét módban a hang mintavételi idejét
használja. OGG Vorbis és Opus is támogatott a mellékelt libsndfile által.
A fájlt részletekben olvassa, ezért hosszú felvételt sem tölt egyszerre memóriába.
Többcsatornás fájlnál az **első csatornát** használja. Ha a jel csak a másik
csatornán van, előbb alakítsa át a fájlt.

## Frekvencia, szűrés és zaj

- **Középfrekvencia:** 300–1500 Hz, alapérték 800 Hz.
- **Sávszélesség:** teljes áteresztett sáv, 50–1000 Hz. A 800/200 beállítás
  700–900 Hz közötti sávot jelent. Az alsó sávszél legalább 20 Hz legyen.
- A sávszűrő 4. rendű Butterworth-tervből készített, 8 pólusú sáváteresztő
  szűrő, folyamatos állapotmegőrzéssel.
- **Zajzár:** −80…−6 dBFS. A kevésbé negatív érték erősebb jelet kíván;
  gyenge jelhez csökkentse, téves jelek esetén növelje.
- **Adaptív zajzár:** a sávban és egy szomszédos sávban mért zaj alapján
  további küszöböt alkalmaz; a rövid impulzusokat is elnyomja. Kikapcsolása
  mellett a sávszűrő és a kézi zajzár továbbra is működik.
- Keskeny sáv jobban elnyomja a távoli zavarokat, de gyors adásnál elmossa
  a rövid jeleket. Kezdésnek 200 Hz ajánlott; gyors vételnél 300–400 Hz-et
  is érdemes kipróbálni.

A középfrekvencia, sávszélesség, kézi zajzár és adaptív zajzár menet közben
is módosítható, élő hangnál, fájlnál és tesztjelnél egyaránt. A frekvencia-,
sávszélesség- és zajzármező mellett kis csúszkák is vannak; a csúszka és a
beírt érték egymást követi. A mezők nyilaival is állíthatja az értékeket. A program
körülbelül 120 ms-onként alkalmazza az új értékeket, húzás közben is,
és az aktív szűrőt a beállítások alatt jelzi. Nincs szükség leállításra vagy
külön alkalmazás gombra. Hibás értéknél a korábbi, érvényes szűrő működik tovább.
Áthangoláskor a már dekódolt szöveg megmarad, a félbeszakított karaktert
elveti, és a következő teljes karaktertől folytatja a vételt. A WPM és az
automatikus sebességkövetés továbbra is leállított vételnél állítható.

Nem beszédfelismerő:
egyetlen, nagyjából állandó frekvenciájú CW hangot vár. A sávon belüli másik
adó, erős szomszédos zavar, fading, kézi adás vagy nagyon rossz jel/zaj viszony
ronthatja az eredményt. Az ismeretlen pont–vonal sorozat jele: `�`.

## Sebesség és szöveg

A **Kezdősebesség** 5–60 WPM között állítható. Állítsa az adó közelítő
sebességére. Az **Automatikus sebességkövetés** a pontok és vonalak
időtartamából finomítja ezt; nem garantál tetszőleges kezdősebességből
azonnali felismerést. Szabványos 1:3 pont/vonal és 1:3:7 szünetarányokat vár.
Farnsworth-időzítés külön nem támogatott. Betűk, számok, gyakori írásjelek és
néhány nemzetközi ékezetes karakter támogatott; több jelentésű szolgálati
jelekhez nincs külön üzemmód.

A szöveg szerkeszthető, másolható és **Szöveg mentése…** gombbal vagy
**Ctrl+S** kombinációval UTF-8 TXT fájlba menthető. Új vétel új sorban
folytatódik. A **Leállítás** a félbeszakított karaktert elveti, hogy ne
keletkezzen egy levágott vonalból téves betű. Nincs automatikus mentés.

## AFC: automatikus frekvenciakövetés

Az **AFC** kapcsoló a Leállítás gomb mellett található, és vétel közben is
kapcsolható. Alapértelmezésben ki van kapcsolva. Bekapcsolva a nyers hang
spektrumában kizárólag az aktuális áteresztett sávon belül keres stabil,
kiemelkedő csúcsot. Egy erősebb, sávon kívüli csúcsot nem választ célpontnak.
Az átmeneti zajt és a sávszéli, erős külső jel okozta hamis csúcsokat szűri.

Három egymást követő becslés után finoman a jelre hangolja a sávközepet.
A frekvenciamező, a csúszka és a spektrum középvonala együtt követi ezt.
A kijelzőn az AFC állapota: **ki**, **keresés**, **követés** vagy **készenlét**.
Jel nélkül megtartja a legutóbbi frekvenciát; kikapcsolásakor azon marad.
Az AFC nem keres a teljes hangfrekvenciás tartományban: az induló jelet előbb
kézzel helyezze az áteresztett sávba. A lassú követés megőrzi a Morse-időzítést,
nem veti el minden finom korrekciónál az aktuális karaktert.

## ORIGAMISAT CW telemetria

Az **ORIGAMISAT CW** gomb a mellékelt, változatlan `cw_converter.exe`
programot külön konzolablakban indítja el. Vétel közben is megnyitható;
önálló folyamatként a főprogram bezárása után is működhet.

A konverter már dekódolt, szöveges telemetriát vár, nem közvetlen hangot.
A Morse-ablak **Másolás** gombjával másolja ki a szöveget, és a konverterbe
illesszen egy teljes telemetria-sort: hívójel, műholdnév, majd a hexadecimális
adatbájtok szóközökkel elválasztva. A konverterben Enter indítja az átalakítást.
Minta és eredménye: `cw_converter/EXAMPLE.txt`; eredeti útmutató:
`cw_converter/README.txt`. A teljes `cw_converter` mappát hagyja az EXE mellett.
A program saját MIT licence nem módosítja a külső konverter feltételeit.

## Hangkimaradások kezelése

A hangfogadás külön szálon, nagyobb késleltetéstűrésű beállítással és legfeljebb
két másodperces feldolgozási pufferrel történik. A dekódolás és a spektrum
számítása így nem közvetlenül a hangkártya olvasási ciklusában fut.
Rövid túlcsordulásnál a program jelzi és számlálja a kimaradásokat, elveti a
félbeszakadt karaktert, újraszinkronizál és automatikusan folytatja a vételt.
Az elveszett minták nem állíthatók helyre, ezért egy-egy karakter kimaradhat.
Eszközmegnyitási vagy tartós illesztőprogramhibánál továbbra is hibát jelez.

## Ha a hangbemenet nem nyílik meg

Frissítse az eszközlistát, és válassza ki a megfelelő bemenetet. Ugyanaz az
eszköz több hangrendszerrel is megjelenhet (MME, DirectSound, WASAPI):
próbáljon másik változatot. Ellenőrizze a Windows hangbemeneti és mikrofon-
hozzáférési beállításait, a csatlakoztatást, illetve hogy más alkalmazás nem
foglalta-e le kizárólagosan az eszközt. A program nem módosít rendszerbeállításokat.
Az aktuális környezetben az élő eszközpróba PortAudio/illesztőprogramhibával
végződött; ezért a valós hangkártyás vétel működését ezen a gépen nem sikerült
igazolni. A fájlfeldolgozás és a szimulált élő adatfolyam tesztje sikeres.

## Beépített próba

A **Tesztjel indítása** belsőleg feldolgozza ezt a szöveget:

`CQ CQ DE HA5ABC SOS 123`

A tesztjel frekvenciája és sebessége a vételi beállításokat követi.
A **Tesztzaj** −90…−12 dBFS közötti fehér zajt kever hozzá; ez csak a
tesztjelet módosítja. A **Tesztjel mentése** WAV vagy OGG fájlt készít.
A csomag `examples` mappájában kész, 800 Hz / 20 WPM mintafájlok is vannak.

## Indítás forrásból és új EXE készítése

64 bites Python 3.13 szükséges, Tcl/Tk támogatással. A program mappájában:

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe morse_app.py
```

Windows EXE-hez futtassa a `build_windows.bat` fájlt. Ez telepíti a
`requirements-build.txt` csomagjait, lefuttatja a teszteket, összegyűjti a
licenceket és PyInstallerrel létrehozza a `dist\MorseDekodolo` mappát.
Az első telepítéshez internet kell, a kész program offline működik.
A teljes mappát csomagolja ZIP-be, ne csak az EXE-t.

Parancssori fájldekódolás (Pythonból):

```powershell
python morse_app.py --decode examples\morse_800Hz.wav --wpm 20 --output szoveg.txt
python -m unittest -v test_decoder
```

## Szabad felhasználás

A program MIT licencű: ingyenesen használható, módosítható és
továbbadható. A külső összetevők licencei a `licenses` mappában találhatók;
ezeket továbbadáskor őrizze meg. Részletek és források: `THIRD_PARTY.md`.
A programhoz nem szükséges előfizetés, fizetős SDK vagy internetes szolgáltatás.

A külső hangkönyvtárak forrásai külön, `MorseDekodolo-konyvtarforrasok.zip`
néven érhetők el. Ha a Windows-programot letöltésként továbbadja, ezt a
könyvtárforrás-csomagot is tegye ugyanott, ingyenesen elérhetővé.
