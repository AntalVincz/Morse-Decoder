【CW変換ツール 使用方法】

1. ZIPファイルを展開してください。
2. cw_converter.exe をダブルクリックして起動してください。
   注意：起動時にセキュリティ警告が表示される場合がありますが、そのまま起動して問題ありません。
3. 画面の指示に従って、CWテレメトリを入力してください。


[How to Use the CW Conversion Tool]

1. Extract the ZIP file.
2. Double-click cw_converter.exe to start the program.
   Note: When starting the program, a security warning may appear. If this happens, please proceed with opening it.
3. Follow the on-screen instructions to enter the CW telemetry data.







