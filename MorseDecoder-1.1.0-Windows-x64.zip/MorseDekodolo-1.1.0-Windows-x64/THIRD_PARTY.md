# Külső összetevők és továbbadás

Morse Dekódoló 1.1.0 – © 2026 Antal Vincz M0GLU.
Saját kód: MIT, lásd LICENSE.txt.

ORIGAMISAT CW: a `cw_converter` mappa a felhasználó által megadott eredeti
`cw_converter.exe`, `README.txt` és `EXAMPLE.txt` fájlokat változatlanul
tartalmazza. A felhasználó tájékoztatása szerint a konverter ingyenes és
szabadon terjeszthető. Külön licencfájl nem szerepelt a megadott csomagban;
a Morse Dekódoló MIT licence nem terjed ki a külső konverterre. Az eredeti
útmutató és mintafájl a Névjegy külső összetevői között is olvasható.

| Összetevő | Licenc | Forrás |
| --- | --- | --- |
| Python 3.13.5 | PSF és mellékelt komponenslicencek | https://www.python.org/downloads/release/python-3135/ |
| Tcl/Tk 8.6 | BSD jellegű Tcl/Tk licenc | https://www.tcl.tk/software/tcltk/ |
| NumPy 2.5.4 | BSD-3-Clause és a bináris csomag mellékelt licencei | https://github.com/numpy/numpy |
| SciPy 1.18.1 | BSD-3-Clause és a bináris csomag mellékelt licencei | https://github.com/scipy/scipy |
| sounddevice 0.5.6 | MIT | https://github.com/spatialaudio/python-sounddevice |
| PortAudio 19.7 | MIT jellegű PortAudio licenc, ASIO nélküli DLL | https://github.com/PortAudio/portaudio |
| soundfile 0.14.0 | BSD-3-Clause | https://github.com/bastibe/python-soundfile |
| libsndfile 1.2.2 | LGPL-2.1-or-later | https://github.com/libsndfile/libsndfile/tree/1.2.2 |
| A libsndfile DLL statikus kodekjei: libogg, Vorbis 1.3.7, FLAC 1.4.3, Opus 1.5.2 | BSD jellegű licencek | https://xiph.org/ |
| mpg123 1.32.9 és LAME 3.100 a libsndfile DLL-ben | LGPL | https://mpg123.org/ és https://lame.sourceforge.io/ |
| CFFI 2.1.1 | MIT; a csomag libffi-licencével | https://cffi.readthedocs.io/ |
| pycparser 3.12 | BSD-3-Clause | https://github.com/eliben/pycparser |
| typing_extensions 4.16.0 | PSF-2.0 | https://github.com/python/typing_extensions |
| PyInstaller 6.22.3 (build eszköz) | GPL kivétellel / Apache-2.0 | https://pyinstaller.org/en/stable/license.html |

A `licenses` mappa az eredeti, teljes licencszövegeket tartalmazza, köztük
a NumPy/SciPy binárisokban szereplő könyvtárak értesítéseit is. A
`collect_licenses.py` ezeket a telepített csomagokból másolja ki.

A libsndfile dinamikus könyvtárként kerül a csomagba
(`_internal/_soundfile_data/libsndfile_x64.dll`). Azonos interfészű saját
fordításra kicserélhető. A Windows ZIP forráskódot és buildfájlokat nem tartalmaz;
az LGPL-könyvtár módosításához szükséges hibakeresést/visszafejtést e program
licence nem korlátozza. A külön letölthető
`MorseDekodolo-konyvtarforrasok.zip` a hangkönyvtárak forrásait és
buildinformációit tartalmazza. A futtatáshoz ezt nem kell letölteni.
Újabb könyvtárverzióval végzett saját build esetén a hozzá tartozó licenceket
és szükséges forrásokat is frissítse.

Hivatalos licencinformációk:

- https://python-sounddevice.readthedocs.io/en/latest/
- https://python-soundfile.readthedocs.io/en/latest/
- https://scipy.org/faq/
- https://pyinstaller.org/en/stable/license.html

A Windows-csomag megőrzi a dokumentációt és a licenceket. Letöltésként
történő továbbadáskor a külön könyvtárforrás-csomagot is tegye ugyanott,
azonos feltételekkel, ingyenesen elérhetővé. Az LGPL-2.1 4. és 6(d)
szakaszának szövege: https://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
